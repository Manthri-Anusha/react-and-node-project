import React, { useState, useEffect } from "react";
import ProductCard from "./ProductCard";
import axiosInstance from "../api/axiosInstance";
import { useParams } from "react-router-dom";

const CategoryPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const { category } = useParams();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axiosInstance.get(`/products/${category}`);
        if (response.status >= 200 && response.status < 300) {
          const data = response.data;
          setProducts(data);
          setLoading(false);
        } else {
          console.log(`Failed to fetch ${category} data`);
          throw new Error(`Failed to fetch ${category} data`);
        }
      } catch (error) {
        console.error(error);
      }
    };

    fetchProducts();
  }, [category]);


  if (loading) {
    return <div className='min-h-screen flex items-center justify-center'>Loading...</div>;
}

  return (
    <>
      <div className="min-h-screen p-10 bg-gray-100 rounded-lg shadow-md">
        <h1 className="title text-3xl font-bold text-gray-800 mb-4">{`${category}`}</h1>
        <div className="product-container grid grid-cols-3 md:grid-cols-5 gap-6">
          {products.map((product, index) => (
            <ProductCard key={index} product={product.gadget} category={product.category} />
          ))}
        </div>
      </div>
    </>
  );
};

export default CategoryPage;
