import React from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../api/axiosInstance";
import { useAuth } from "../Context/Context";

const ProductCard = ({ product, category }) => {
  const {isLoggedIn} = useAuth();
  const navigate = useNavigate();
  const {
    "Product Name": productName,
    "Price in India": priceInIndia,
    "Picture URL": pictureURL,
    url,
  } = product;

  const handleClick = async () => {
    if(isLoggedIn){
    try {
      await axiosInstance.post("/products/interacts", {
        url: url,
        category: category,
      });
      navigate(`/product/${category}/${productName}`)
    } catch (error) {
      console.error("Error recording interaction:", error);
    }
  }else{
    navigate('/login');
  }
  };

  return (
    <div className="product-card-container border border-gray-300 rounded-md shadow-sm p-4 mb-4">
      <a href={url} target="_blank" rel="noopener noreferrer">
        <img src={pictureURL} alt={productName} className="max-w-full h-auto" />
      </a>
      <div className="product-card-info mt-4">
        <h3 className="text-lg font-semibold mb-1">{productName}</h3>
        <p className="text-base text-gray-600">Price: {priceInIndia}</p>
        <button
          onClick={handleClick}
          className="block w-1/2 mt-2 text-center rounded bg-blue-500 text-white font-semibold py-2 px-4 transition duration-300 ease-in-out hover:bg-blue-600"
        >
          More
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
