import React from "react";
import { Route, Navigate } from "react-router-dom";

const isAuthenticated = () => {
  const token = sessionStorage.getItem("email");
  return !!token;
};

const PrivateRoute = ({ component: Component, ...rest }) => {
  return (
    <Route
      {...rest}
      render={(props) =>
        isAuthenticated() ? <Component {...props} /> : <Navigate to="/login" />
      }
    />
  );
};

export default PrivateRoute;
