import React, { useState, useEffect } from "react";
import axiosInstance from "../api/axiosInstance";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../Context/Context";
import toastr from "toastr";

const Profile = () => {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({});
  const navigate = useNavigate();
  const { logout } = useAuth();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axiosInstance.get("/auth/getCurrentUser");
        setUser(response.data.user);
        console.log(response.data.user);
        // Populate form data with user details
        setFormData(response.data.user);
      } catch (error) {
        console.error("Error fetching user information:", error);
      }
    };

    fetchUser();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleUpdate = async () => {
    try {
      // Send updated user details to the backend
      await axiosInstance.put("/auth/updateUser", formData);
      console.log("User information updated successfully");
      toastr.success("User details updated!", "Success");
      navigate("/");
    } catch (error) {
      console.error("Error updating user information:", error);
      toastr.error("Error updating profile","Error");
    }
  };

  const handleLogout = async () => {
    try {
      await axiosInstance.get("/auth/logout");
      sessionStorage.clear();
      logout();
      console.log("Logged out successfully");
      navigate("/login");
    } catch (error) {
      console.error("Error logging out:", error);
      navigate("/");
    }
  };

  return (
    <div className="container min-h-screen w-1/2 mx-auto px-4 py-8">
      {user ? (
        <div>
          <h1 className="text-2xl font-bold mb-4">Profile Details</h1>
          <div className="mb-4">
            <label htmlFor="name" className="block font-semibold mb-1">First Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name || ""}
              onChange={handleInputChange}
              className="border border-gray-300 rounded px-4 py-2 w-full mb-2"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="lastName" className="block font-semibold mb-1">Last Name:</label>
            <input
              type="text"
              id="lastName"
              name="lastName"
              value={formData.lastName || ""}
              onChange={handleInputChange}
              className="border border-gray-300 rounded px-4 py-2 w-full mb-2"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="email" className="block font-semibold mb-1">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email || ""}
              readOnly
              className="border border-gray-300 rounded px-4 py-2 w-full mb-2"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="location" className="block font-semibold mb-1">Address:</label>
            <input
              type="text"
              id="location"
              name="location"
              value={formData.location || ""}
              onChange={handleInputChange}
              className="border border-gray-300 rounded px-4 py-2 w-full mb-2"
            />
          </div>
          <button
            onClick={handleUpdate}
            className="bg-blue-500 text-white px-4 py-2 rounded mr-4 hover:bg-blue-600"
          >
            Update
          </button>
          <button
            onClick={handleLogout}
            className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
          >
            Logout
          </button>
        </div>
      ) : (
        <div className="min-h-screen">Loading...</div>
      )}
    </div>
  );
};

export default Profile;
