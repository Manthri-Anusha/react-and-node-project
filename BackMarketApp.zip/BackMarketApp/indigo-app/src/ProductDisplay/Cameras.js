import React from 'react';
import { useCart } from '../Context/cartContext';
import { useParams } from 'react-router-dom';

const CamerasDetails = ({ product }) => {
    const { addToCart } = useCart();
    const { category } = useParams();

    const {
        "Product Name": productName,
        "Price in India": priceInIndia,
        "Picture URL": pictureURL,
        "Temperature": temperature,
        "Model Name": modelName,
        "Built-in Flash": builtInFlash,
        "Dimensions(WxHxD)": dimensions,
        "Effective Pixels": effectivePixels,
        "Self-timer": selfTimer,
        "Battery Type": batteryType,
        "Weight": weight,
        "Brand": brand,
        "Type": type,
        "Display Size": displaySize,
        "Sensor Type": sensorType,
        "Auto Focus": autoFocus,
        "Model": model,
        url
    } = product;

    const handleAddToCart = () => {
        addToCart(category, productName, priceInIndia);
        alert('Item added to cart successfully');
    };

    return (
        <div className="bg-white shadow-lg mx-auto mt-8 rounded-lg overflow-hidden max-w-xl">
            <img src={pictureURL} alt={productName} className="max-w-full h-auto mx-auto" />
            <div className="p-4 flex flex-col justify-center">
                <h2 className="text-xl font-semibold mb-2 text-center">{productName}</h2>
                <p className="text-gray-700 mb-2 text-center">Price: {priceInIndia}</p>
                <div className="grid grid-cols-2 gap-2">
                    <div>
                        <p><span className="font-semibold">Temperature:</span> {temperature}</p>
                        <p><span className="font-semibold">Model Name:</span> {modelName}</p>
                        <p><span className="font-semibold">Built-in Flash:</span> {builtInFlash}</p>
                        <p><span className="font-semibold">Dimensions:</span> {dimensions}</p>
                        <p><span className="font-semibold">Effective Pixels:</span> {effectivePixels}</p>
                    </div>
                    <div>
                        <p><span className="font-semibold">Self-timer:</span> {selfTimer}</p>
                        <p><span className="font-semibold">Battery Type:</span> {batteryType}</p>
                        <p><span className="font-semibold">Weight:</span> {weight}</p>
                        <p><span className="font-semibold">Brand:</span> {brand}</p>
                        <p><span className="font-semibold">Type:</span> {type}</p>
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-2">
                    <div>
                        <p><span className="font-semibold">Display Size:</span> {displaySize}</p>
                        <p><span className="font-semibold">Sensor Type:</span> {sensorType}</p>
                        <p><span className="font-semibold">Auto Focus:</span> {autoFocus}</p>
                    </div>
                    <div>
                        <p><span className="font-semibold">Model:</span> {model}</p>
                    </div>
                </div>
                <div className="flex justify-center mt-4">
                    <button onClick={handleAddToCart} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded mr-2">Add to Cart</button>
                    <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded ml-2 transition duration-300 ease-in-out"
                    >
                        Visit Site
                    </a>
                </div>
            </div>
        </div>
    );
};

export default CamerasDetails;
