import React from 'react';
import { useCart } from '../Context/cartContext';
import { useParams } from 'react-router-dom';

const MobilesDetails = ({ product }) => {
    const { addToCart } = useCart();
    const {category} = useParams();

  const {
    "Product Name": productName,
    "Price in India": priceInIndia,
    "Picture URL": pictureURL,
    RAM,
    "Internal storage": internalStorage,
    "Bluetooth": bluetooth,
    "Processor": processor,
    "Launched": launched,
    "GPS": GPS,
    "Total Ratings": totalRatings,
    "Operating system": operatingSystem,
    "Touchscreen": touchscreen,
    "Wi-Fi": WiFi,
    "Front camera": frontCamera,
    "Screen size (inches)": screenSize,
    url,
    "Brand": brand,
    "Rear camera": rearCamera,
    "Model": model,
    "Resolution": resolution
  } = product;

  const handleAddToCart = () => {
    if (product) {
        addToCart(category, productName, priceInIndia);
        alert('Item added to cart successfully');
    }
};

  return (
    <div className="bg-white shadow-lg mx-auto mt-8 rounded-lg overflow-hidden max-w-xl">
      <img src={pictureURL} alt={productName} className="max-w-full h-auto mx-auto" />
      <div className="p-4 flex flex-col justify-center">
        <h2 className="text-xl font-semibold mb-2 text-center">{productName}</h2>
        <p className="text-gray-700 mb-2 text-center">Price: {priceInIndia}</p>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <p><span className="font-semibold">RAM:</span> {RAM}</p>
            <p><span className="font-semibold">Internal Storage:</span> {internalStorage}</p>
            <p><span className="font-semibold">Bluetooth:</span> {bluetooth}</p>
            <p><span className="font-semibold">Processor:</span> {processor}</p>
            <p><span className="font-semibold">Launched:</span> {launched}</p>
            <p><span className="font-semibold">GPS:</span> {GPS}</p>
            <p><span className="font-semibold">Total Ratings:</span> {totalRatings}</p>
          </div>
          <div>
            <p><span className="font-semibold">Operating system:</span> {operatingSystem}</p>
            <p><span className="font-semibold">Touchscreen:</span> {touchscreen}</p>
            <p><span className="font-semibold">Wi-Fi:</span> {WiFi}</p>
            <p><span className="font-semibold">Front camera:</span> {frontCamera}</p>
            <p><span className="font-semibold">Screen size (inches):</span> {screenSize}</p>
            <p><span className="font-semibold">Brand:</span> {brand}</p>
            <p><span className="font-semibold">Rear camera:</span> {rearCamera}</p>
            <p><span className="font-semibold">Model:</span> {model}</p>
            <p><span className="font-semibold">Resolution:</span> {resolution}</p>
          </div>
        </div>
        <div className="flex justify-center mt-4">
          <button onClick={handleAddToCart} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded mr-2">Add to Cart</button>
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded ml-2 transition duration-300 ease-in-out"
          >
            Visit Site
          </a>
        </div>
      </div>
    </div>
  );
};

export default MobilesDetails;
