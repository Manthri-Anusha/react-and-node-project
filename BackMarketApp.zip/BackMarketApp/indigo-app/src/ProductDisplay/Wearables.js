import React from 'react';
import { useCart } from '../Context/cartContext';
import { useParams } from 'react-router-dom';

const WearablesDetails = ({ product }) => {
    const { addToCart } = useCart();
    const { category } = useParams();

    const {
        "Product Name": productName,
        "Price in India": priceInIndia,
        "Picture URL": pictureURL,
        "Brand": brand,
        "Model Name": modelName,
        "Strap Material": strapMaterial,
        "Bluetooth": bluetooth,
        "Size": size,
        "Ideal For": idealFor,
        "Water Resistant": waterResistant,
        "Dial Shape": dialShape,
        "Battery Life": batteryLife,
        "Date & Time Display": dateTimeDisplay,
        "Heart Rate Monitor": heartRateMonitor,
        url
    } = product;

    const handleAddToCart = () => {
        if (product) {
            addToCart(category, productName, priceInIndia);
            alert('Item added to cart successfully');
        }
    };

    return (
        <div className="bg-white shadow-lg mx-auto mt-8 rounded-lg overflow-hidden max-w-xl">
            <img src={pictureURL} alt={productName} className="max-w-full h-auto mx-auto" />
            <div className="p-4 flex flex-col justify-center">
                <h2 className="text-xl font-semibold mb-2 text-center">{productName}</h2>
                <p className="text-gray-700 mb-2 text-center">Price: {priceInIndia}</p>
                <div>
                    <p><span className="font-semibold">Brand:</span> {brand}</p>
                    <p><span className="font-semibold">Model Name:</span> {modelName}</p>
                    <p><span className="font-semibold">Strap Material:</span> {strapMaterial}</p>
                    <p><span className="font-semibold">Bluetooth:</span> {bluetooth}</p>
                    <p><span className="font-semibold">Size:</span> {size}</p>
                    <p><span className="font-semibold">Ideal For:</span> {idealFor}</p>
                    <p><span className="font-semibold">Water Resistant:</span> {waterResistant}</p>
                    <p><span className="font-semibold">Dial Shape:</span> {dialShape}</p>
                    <p><span className="font-semibold">Battery Life:</span> {batteryLife}</p>
                    <p><span className="font-semibold">Date & Time Display:</span> {dateTimeDisplay}</p>
                    <p><span className="font-semibold">Heart Rate Monitor:</span> {heartRateMonitor}</p>
                </div>
                <div className="flex justify-center mt-4">
                    <button onClick={handleAddToCart} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded mr-2">Add to Cart</button>
                    <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded ml-2 transition duration-300 ease-in-out"
                    >
                        Visit Site
                    </a>
                </div>
            </div>
        </div>
    );
};

export default WearablesDetails;
