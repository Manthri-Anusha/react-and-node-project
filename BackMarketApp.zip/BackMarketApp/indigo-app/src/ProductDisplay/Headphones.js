import React from 'react';
import { useCart } from '../Context/cartContext';
import { useParams } from 'react-router-dom';

const HeadphonesDetails = ({ product }) => {
    const { addToCart } = useCart();
    const { category } = useParams();

    const {
        "Product Name": productName,
        "Price in India": priceInIndia,
        "Picture URL": pictureURL,
        "Bluetooth": bluetooth,
        "Microphone": microphone,
        "Launched": launched,
        "Brand": brand,
        "Type": type,
        "Headphone Type": headphoneType,
        "Model": model,
        "Connectivity": connectivity,
        url
    } = product;

    const handleAddToCart = () => {
        addToCart(category, productName, priceInIndia);
        alert('Item added to cart successfully');
    };

    return (
        <div className="bg-white shadow-lg mx-auto mt-8 rounded-lg overflow-hidden max-w-xl">
            <img src={pictureURL} alt={productName} className="max-w-full h-auto mx-auto" />
            <div className="p-4 flex flex-col justify-center">
                <h2 className="text-xl font-semibold mb-2 text-center">{productName}</h2>
                <p className="text-gray-700 mb-2 text-center">Price: {priceInIndia}</p>
                <div className="grid grid-cols-2 gap-2">
                    <div>
                        <p><span className="font-semibold">Bluetooth:</span> {bluetooth}</p>
                        <p><span className="font-semibold">Microphone:</span> {microphone}</p>
                        <p><span className="font-semibold">Launched:</span> {launched}</p>
                        <p><span className="font-semibold">Brand:</span> {brand}</p>
                        <p><span className="font-semibold">Type:</span> {type}</p>
                    </div>
                    <div>
                        <p><span className="font-semibold">Headphone Type:</span> {headphoneType}</p>
                        <p><span className="font-semibold">Model:</span> {model}</p>
                        <p><span className="font-semibold">Connectivity:</span> {connectivity}</p>
                    </div>
                </div>
                <div className="flex justify-center mt-4">
                    <button onClick={handleAddToCart} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded mr-2">Add to Cart</button>
                    <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded ml-2 transition duration-300 ease-in-out"
                    >
                        Visit Site
                    </a>
                </div>
            </div>
        </div>
    );
};

export default HeadphonesDetails;
