import React from 'react';
import { useCart } from '../Context/cartContext';
import { useParams } from 'react-router-dom';

const TelevisionDetails = ({ product }) => {
    const { addToCart } = useCart();
    const { category } = useParams();

    const {
        "Product Name": productName,
        "Price in India": priceInIndia,
        "Picture URL": pictureURL,
        "Brand": brand,
        "Model": model,
        "Model Name": modelName,
        "Color": color,
        "Screen Type": screenType,
        "Display Size": displaySize,
        "Resolution (pixels)": resolution,
        "Resolution Standard": resolutionStandard,
        "Smart TV": smartTV,
        "Analog Audio Input": analogAudioInput,
        "Speaker Output RMS": speakerOutputRMS,
        "Power Consumption": powerConsumption,
        url
    } = product;

    const handleAddToCart = () => {
        if (product) {
            addToCart(category, productName, priceInIndia);
            alert('Item added to cart successfully');
        }
    };

    return (
        <div className="bg-white shadow-lg mx-auto mt-8 rounded-lg overflow-hidden max-w-xl">
            <img src={pictureURL} alt={productName} className="max-w-full h-auto mx-auto" />
            <div className="p-4 flex flex-col justify-center">
                <h2 className="text-xl font-semibold mb-2 text-center">{productName}</h2>
                <p className="text-gray-700 mb-2 text-center">Price: {priceInIndia}</p>
                <div className="grid grid-cols-2 gap-2">
                    <div>
                        <p><span className="font-semibold">Brand:</span> {brand}</p>
                        <p><span className="font-semibold">Model Name:</span> {modelName}</p>
                        <p><span className="font-semibold">Color:</span> {color}</p>
                        <p><span className="font-semibold">Screen Type:</span> {screenType}</p>
                        <p><span className="font-semibold">Display Size:</span> {displaySize}</p>
                       
                    </div>
                    <div>
                        <p><span className="font-semibold">Resolution:</span> {resolution}</p>
                        <p><span className="font-semibold">Resolution Standard:</span> {resolutionStandard}</p>
                        <p><span className="font-semibold">Smart TV:</span> {smartTV}</p>
                        <p><span className="font-semibold">Analog Audio Input:</span> {analogAudioInput}</p>
                        <p><span className="font-semibold">Speaker Output RMS:</span> {speakerOutputRMS}</p>
                        <p><span className="font-semibold">Power Consumption:</span> {powerConsumption}</p>
                    </div>
                </div>
                <div className="flex justify-center mt-4">
                    <button onClick={handleAddToCart} className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded mr-2">Add to Cart</button>
                    <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded ml-2 transition duration-300 ease-in-out"
                    >
                        Visit Site
                    </a>
                </div>
            </div>
        </div>
    );
};

export default TelevisionDetails;
