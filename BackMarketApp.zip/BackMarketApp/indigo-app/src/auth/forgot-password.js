import React, { useState } from "react";
import axiosInstance from "../api/axiosInstance";

const ForgotPassword = () => {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");

  const sendResetPasswordEmail = async () => {
    if (!email) {
      setError("Please enter your email");
      return;
    }

    try {
      await axiosInstance.post("/password/forgotpassword", {
        email,
      });
      console.log("OTP sent successfully");
      setStep(2);
    } catch (err) {
      console.error("Error sending reset password email:", err);
      setError(err.response.data.error || "Error sending reset password email");
    }
  };

  const verifyOTP = async () => {
    if (!otp) {
      setError("Please enter OTP");
      return;
    }

    try {
      await axiosInstance.post("/password/verifyotp", {
        email,
        otp,
      });
      console.log("OTP verified successfully");
      setStep(3);
    } catch (err) {
      console.error("Error verifying OTP:", err);
      setError(err.response.data.error || "Error verifying OTP");
    }
  };

  const setPassword = async () => {
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    if (!newPassword) {
      setError("Please enter your new password");
      return;
    }

    try {
      await axiosInstance.post("/password/resetpassword", {
        email,
        otp,
        newPassword,
      });
      console.log("New password set successfully");
      // Redirect to login page or perform any other action upon success
    } catch (err) {
      console.error("Error setting new password:", err);
      setError(err.response.data.error || "Error setting new password");
    }
  };

  const passwordsMatch = () => newPassword === confirmPassword;

  return (
    <div className="min-h-screen max-w-md mx-auto my-8 p-6 bg-white rounded shadow-md">
      {step === 1 && (
        <>
          <h2 className="text-xl font-bold mb-4">Forgot Password - Step 1</h2>
          {error && <p className="text-red-500">{error}</p>}
          <input
            className="w-full px-3 py-2 mb-4 border rounded"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
          />
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={sendResetPasswordEmail}
          >
            Send Reset Password Email
          </button>
        </>
      )}
      {step === 2 && (
        <>
          <h2 className="text-xl font-bold mb-4">Forgot Password - Step 2</h2>
          {error && <p className="text-red-500">{error}</p>}
          <input
            className="w-full px-3 py-2 mb-4 border rounded"
            type="text"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            placeholder="Enter OTP"
          />
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={verifyOTP}
          >
            Verify OTP
          </button>
        </>
      )}
      {step === 3 && (
        <>
          <h2 className="text-xl font-bold mb-4">Forgot Password - Step 3</h2>
          {error && <p className="text-red-500">{error}</p>}
          <input
            className="w-full px-3 py-2 mb-4 border rounded"
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="Enter New Password"
          />
          <input
            className="w-full px-3 py-2 mb-4 border rounded"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="Confirm New Password"
          />
          {!passwordsMatch() && (
            <p className="text-red-500">Passwords do not match</p>
          )}
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={setPassword}
          >
            Set New Password
          </button>
        </>
      )}
    </div>
  );
};

export default ForgotPassword;
