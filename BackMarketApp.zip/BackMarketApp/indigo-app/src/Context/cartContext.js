import React, { createContext, useState, useContext, useEffect } from "react";
import axiosInstance from "../api/axiosInstance";

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    fetchCartItems();
  }, []);

  const fetchCartItems = async () => {
    try {
      const response = await axiosInstance.get("/cart/view");
      setCartItems(response.data.cartItems);
      
    } catch (error) {
      console.error("Error fetching cart items:", error);
    }
  };

  const addToCart = async (category, productName, priceInIndia) => {
    try {
      await axiosInstance.post("/cart/add", {
        category,
        productName,
        priceInIndia,
      });
      fetchCartItems();
    } catch (error) {
      console.error("Error adding item to cart:", error);
    }
  };

  const removeFromCart = async (productName) => {
    try {
      await axiosInstance.post("/cart/remove", { productName });
      fetchCartItems();
      
    } catch (error) {
      console.error("Error removing item from cart:", error);
    }
  };
  
  

  const cartContextValue = {
    cartItems,
    addToCart,
    removeFromCart,
  };

  return (
    <CartContext.Provider value={cartContextValue}>
      {children}
    </CartContext.Provider>
  );
};
