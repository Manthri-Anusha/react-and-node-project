import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./components/Homepage";
import Layout from "./components/Layout";
import Login from "./auth/login";
import Register from "./auth/register";
import ForgotPassword from "./auth/forgot-password";
import Profile from "./profile/details";
import 'toastr/build/toastr.min.css';
import ProductDetails from "./components/ProductDetails";
import { AuthRoutes } from "./utils/authRoutes";
import SearchComponent from "./components/Search";
import { CartProvider } from "./Context/cartContext";
import CartList from "./components/CartList";
import CategoryPage from "./Products/Product";
import SearchHistory from "./components/History";
import PaymentPage from "./components/Payment";


function App() {
  return (
    
      <Router>
        <Layout>
          <CartProvider>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/product/:category" element={<CategoryPage/>} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/profile" element={<AuthRoutes Component={Profile} />} />
          <Route path="/cart" element={<AuthRoutes Component={CartList} />} />
          <Route path="/search" element={<AuthRoutes Component={SearchComponent} />} />
          <Route path="/history" element={<AuthRoutes Component={SearchHistory} />} />
          <Route path="/payment" element={<AuthRoutes Component={PaymentPage} />} />
          <Route path="/product/:category/:productName" element={<AuthRoutes Component={ProductDetails} />} />
        </Routes>
        </CartProvider>
        </Layout>
      </Router>
  );
}

export default App;
