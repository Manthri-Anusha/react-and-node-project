import React, { useState, useEffect } from 'react';
import axiosInstance from '../api/axiosInstance';
import { useNavigate, useParams } from 'react-router-dom';
import RecommendedProduct from './RecommendedProduct';
import MobilesDetails from '../ProductDisplay/Mobiles';
import LaptopsDetails from '../ProductDisplay/Laptops';
import TelevisionDetails from '../ProductDisplay/Televisions';
import WearablesDetails from '../ProductDisplay/Wearables';
import HeadphonesDetails from '../ProductDisplay/Headphones';
import ConsolesDetails from '../ProductDisplay/Consoles';
import CamerasDetails from '../ProductDisplay/Cameras';
import TabletsDetails from '../ProductDisplay/Tablets';

const ProductDetails = () => {
    const navigate = useNavigate();
    const { category, productName } = useParams();
    const [product, setProduct] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [recommendedProducts, setRecommendedProducts] = useState([]);
    

    useEffect(() => {
        const fetchProduct = async () => {
            try {
                const response = await axiosInstance.get(`/product/${category}/${productName}`);
                if (response.status === 404) {
                    throw new Error('Product not found');
                }
                setProduct(response.data);
                setLoading(false);
            } catch (error) {
                setError(error.message);
                setLoading(false);
            }
        };

        const fetchRecommendedProducts = async () => {
            try {
                const response = await axiosInstance.post('/products/recommendations', { category });
                setRecommendedProducts(response.data);
            } catch (error) {
                console.error('Error fetching recommended products:', error);
            }
        };

        fetchProduct();
        fetchRecommendedProducts();
    }, [category, productName]);


    if (loading) {
        return <div className='min-h-screen'>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    if (!product) {
        return <div>Product not found</div>;
    }

    let productDetailsComponent;

    switch (category) {
        case 'Mobiles':
            productDetailsComponent = <MobilesDetails product={product} />;
            break;
        case 'Tablets':
            productDetailsComponent = <TabletsDetails product={product} />;
            break;
        case 'Laptops':
            productDetailsComponent = <LaptopsDetails product={product} />;
            break;
        case 'Wearables':
            productDetailsComponent = <WearablesDetails product={product} />;
            break;
        case 'Headphones':
            productDetailsComponent = <HeadphonesDetails product={product} />;
            break; 
        case 'Consoles':
            productDetailsComponent = <ConsolesDetails product={product} />;
            break;           
        case 'Televisions':
            productDetailsComponent = <TelevisionDetails product={product} />;
            break;
        case 'Cameras':
            productDetailsComponent = <CamerasDetails product={product} />;
            break;
        default:
            navigate('/');
            break;
    }

    return (
        <div className="product-details-container min-h-screen flex flex-col justify-between">
            <div>
                    <div className="product-details">
                        {productDetailsComponent}
                    </div>
                
            </div>
            <div className="recommended-products mt-auto">
                <h3 className='text-2xl font-bold mb-4'>Recommended Products</h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
                    {recommendedProducts.map((recommendedProduct, index) => (
                        <RecommendedProduct key={index} product={recommendedProduct.similarProduct} category={recommendedProduct.category} />
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ProductDetails;
