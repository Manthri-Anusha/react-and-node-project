import React from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../api/axiosInstance";
import { useAuth } from "../Context/Context";

const MobileCard = ({ mobile, category }) => {
  const { isLoggedIn } = useAuth();
  const navigate= useNavigate();
  const {
    "Product Name": ProductName,
    "Price in India": PriceInIndia,
    "Picture URL": PictureURL,
    url,
  } = mobile;

  const handleClick = async () => {
    if(isLoggedIn){
    try {
      await axiosInstance.post("/products/interacts", {
        url: url,
        category: category,
      });
      navigate(`/product/${category}/${ProductName}`)
    } catch (error) {
      console.error("Error recording interaction:", error);
    }
  }else{
    navigate('/login');
  }
  };

  return (
    <div className="mobile-card-container border border-gray-300 rounded-md shadow-sm p-4 mb-4">
      <a href={url} target="_blank" rel="noopener noreferrer">
        <img src={PictureURL} alt={ProductName} className="max-w-full h-auto" />
      </a>
      <div className="mobile-card-info mt-4">
        <h3 className="text-lg font-semibold mb-1">{ProductName}</h3>
        <p className="text-base text-gray-600">Price: {PriceInIndia}</p>

        <button
          onClick={handleClick}
          className="block w-1/2 mt-2 text-center rounded bg-blue-500 text-white font-semibold py-2 px-4 transition duration-300 ease-in-out hover:bg-blue-600"
        >
          More
        </button>
      </div>
    </div>
  );
};

export default MobileCard;
