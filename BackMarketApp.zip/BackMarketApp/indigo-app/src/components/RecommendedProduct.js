import React from 'react';
import axiosInstance from '../api/axiosInstance';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../Context/Context';

const RecommendedProduct = ({ product, category }) => {
    const {isLoggedIn} = useAuth();
    const navigate = useNavigate();
  const {
    "Product Name": productName,
    "Price in India": priceInIndia,
    "Picture URL": pictureURL,
    url,
  } = product;

  const handleClick = async () => {
    if(isLoggedIn){
    try {
      await axiosInstance.post("/products/interacts", {
        url: url,
        category: category,
      });
      navigate(`/product/${category}/${productName}`)
    } catch (error) {
      console.error("Error recording interaction:", error);
    }
}else{
    navigate('/login');
}
  };

  return (
    <div className="recommended-product bg-white shadow-lg rounded-lg overflow-hidden">
      <img src={pictureURL} alt={productName} className="block max-w-full h-auto" />
      <div className="recommended-product-info p-4">
        <h3 className="text-lg font-semibold mt-2">{productName}</h3>
        <p className="text-gray-700 mb-2">Price: {priceInIndia}</p>
        <button
          onClick={handleClick}
          className="block w-1/2 mt-2 text-center rounded bg-blue-500 text-white font-semibold py-2 px-4 transition duration-300 ease-in-out hover:bg-blue-600"
        >
          More
        </button>
      </div>
    </div>
  );
};

export default RecommendedProduct;
