import { Link, useNavigate } from "react-router-dom";
import { FaBars, FaUser, FaShoppingCart, FaSearch } from "react-icons/fa";
import { useEffect, useState } from "react";
import { useAuth } from "../Context/Context";
import "../App.css";
import axiosInstance from "../api/axiosInstance";

const Navbar = () => {
  const { isLoggedIn } = useAuth();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const navigate = useNavigate();
  const { logout } = useAuth();
  const username = sessionStorage.getItem("name");

  useEffect(() => {
    console.log(isLoggedIn);
  }, []);

  const handleDropdownToggle = () => {
    if (!isLoggedIn) {
      navigate("/login");
    } else {
      setIsDropdownOpen(!isDropdownOpen);
    }
  };

  const handleLogout = async () => {
    try {
      await axiosInstance.get("/auth/logout");
      sessionStorage.clear();
      logout();
      console.log("Logged out successfully");
      navigate("/login");
    } catch (error) {
      console.error("Error logging out:", error);
      navigate("/");
    }
  };

  const handleDropdownClick = () => {
    setIsDropdownOpen(false);
  };

  return (
    <header className="bg-gray-200 sticky text-black z-50">
      <div className="flex items-center justify-between px-4 py-2 relative z-50">
        <div className="flex items-center">
          <FaBars className="h-6 w-6 cursor-pointer mr-2 md:hidden" />
          <Link to="/">
            <p className="text-3xl font-bold text-indigo-500">Indigo Gadgets</p>
          </Link>
        </div>
        <div className="flex items-end">
        <Link to="/search">
        <FaSearch className="h-6 w-6 mr-2 cursor-pointer" />
      </Link>
          <div className="relative z-50">
            <FaUser
              className="h-6 w-6 mr-2 cursor-pointer"
              onClick={handleDropdownToggle}
            />
            {isDropdownOpen && (
              <div
                className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-50"
                onClick={handleDropdownClick} // Add click event handler
              >
                <div className="py-1">
                <div className="text-center bg-gray-300 p-2">Welcome {username}</div>
                <Link
                    to="/"
                    className="block px-4 py-2 text-sm text-gray-800 hover:bg-indigo-500 hover:text-white"
                  >
                    Home
                  </Link>
                  <Link
                    to="/profile"
                    className="block px-4 py-2 text-sm text-gray-800 hover:bg-indigo-500 hover:text-white"
                  >
                    Profile
                  </Link>
                  
                  <Link
                    to="/history"
                    className="block px-4 py-2 text-sm text-gray-800 hover:bg-indigo-500 hover:text-white"
                  >
                    History
                  </Link>
                  <button
                    className="block w-full text-left px-4 py-2 text-sm text-gray-800 hover:bg-indigo-500 hover:text-white"
                    onClick={handleLogout}
                  >
                    Logout
                  </button>

                </div>
                
              </div>
            )}
          </div>
          <div>
            <Link to="/cart">
          <FaShoppingCart className="h-6 w-6 cursor-pointer" />{" "}
          </Link>
          </div>
        </div>
      </div>
      <nav className="bg-gray-700 text-white flex items-center px-6 relative z-100">
        <div className="menu-container flex justify-center">
          <ul className="menu flex gap-4">
            <li>
              <Link to="/product/Mobiles">Mobiles</Link>
            </li>
            <li>
              <Link to="/product/Laptops">Laptops</Link>
            </li>
            <li>
              <Link to="/product/Tablets">Tablets</Link>
            </li>
            <li>
              <Link to="/product/Cameras">Cameras</Link>
            </li>
            <li>
              <Link to="/product/Wearables">Wearables</Link>
            </li>
            <li>
              <Link to="/product/Headphones">Headphones & Speakers</Link>
            </li>
            <li>
              <Link to="/product/Consoles">Gaming Consoles</Link>
            </li>
            <li>
              <Link to="/product/Televisions">Televisions</Link>
            </li>
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;
