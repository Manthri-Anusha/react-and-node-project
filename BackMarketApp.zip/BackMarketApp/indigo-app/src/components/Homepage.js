import React, { useState, useEffect } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import MobileCard from "./Mobilecard";
import axiosInstance from "../api/axiosInstance";
import SimilarProductsSection from "./SimilarProducts";
import { useAuth } from "../Context/Context";

const HomePage = () => {
  const {isLoggedIn} = useAuth();
  const [mobiles, setMobiles] = useState([]);
  const images = [
    "https://images.ctfassets.net/mmeshd7gafk1/3YQzX53QBYZvXBrNLPoJks/aded4922ca1a84780c3bc049effb6efd/GENERIC_HPBANNERS_iPhone13_Desktop_US.jpg",
    "https://images.ctfassets.net/mmeshd7gafk1/3c6DVuZZ92nnOpVacHr8u6/f94d7949e679d137482ccaa9e4c464fb/TRADEIN_HP_GENERICBANNERS_DESKTOP_1_US.jpg",
    "https://images.ctfassets.net/mmeshd7gafk1/3Xpl0rtrXbBRIZDONnbeNm/da1ec02caca4b8dcba2f8c5b31c68d6b/GENERIC_HPBANNERS_iPad2021_Desktop_US.jpg",
    "https://images.ctfassets.net/mmeshd7gafk1/6B8nypobeX6vexMehAJIgQ/e78261a0b1dfcab6a8379da4deddee14/GENERIC_HPBANNERS_GalaxyS21_Desktop_US.jpg"
  ];


  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axiosInstance.get("/products/gadgets");
        if (response.status !== 200) {
          console.error("Failed to fetch mobiles data");
          throw new Error("Failed to fetch mobiles data");
        }
        const data = await response.data;
        setMobiles(data);
      } catch (error) {
        console.error(error);
      }
    };

    fetchData();
  }, []);

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };


  
  return (
    <div className="min-h-screen p-10 bg-gray-100 rounded-lg shadow-xl">
<Slider {...settings} className="w-full h-screen-30">
        {images.map((imageUrl, index) => (
          <div key={index} className="h-full">
            <img src={imageUrl} alt={`Image ${index}`} className="w-full h-full object-cover" />
          </div>
        ))}
      </Slider>
      <h1 className="title text-3xl font-bold text-gray-800 my-4">
        All Products
      </h1>
      <div className="mobile-container grid grid-cols-3 md:grid-cols-5 gap-6">
        {mobiles.map((mobile, index) => (
          <MobileCard key={index} index={index} category={mobile.category} mobile={mobile.gadget} />
        ))}
      </div>
      <div>
      {isLoggedIn && <SimilarProductsSection />}
      </div>
    </div>
  );
};

export default HomePage;
