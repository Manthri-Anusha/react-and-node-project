import React, { useState, useEffect } from 'react';
import axiosInstance from '../api/axiosInstance';
import MobileCard from './Mobilecard';

const SimilarProductsSection = () => {
  const [similarProducts, setSimilarProducts] = useState([]);

  useEffect(() => {
    const fetchSimilarProducts = async () => {
      try {
        const response = await axiosInstance.get('/products/similarProducts');
        setSimilarProducts(response.data);
        console.log(response.data);
      } catch (error) {
        console.error('Error fetching similar products:', error);
      }
    };

    fetchSimilarProducts();
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold ">Recommended Products</h1>
      <p className='text-base  mb-4'>Based on user Interactions</p>
      <div className="mobile-container grid grid-cols-3 md:grid-cols-6 gap-6">
        {similarProducts.map((mobile, index) => (
          <MobileCard key={index} index={index} category={mobile.category} mobile={mobile.gadget} />
        ))}
      </div>
    </div>
  );
};

export default SimilarProductsSection;
