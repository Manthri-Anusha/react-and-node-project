import React, { useState, useEffect } from "react";
import axiosInstance from "../api/axiosInstance";

const SearchHistory = () => {
  const [searchHistory, setSearchHistory] = useState([]);

  useEffect(() => {
    fetchSearchHistory();
  }, []);

  const fetchSearchHistory = async () => {
    try {
      const response = await axiosInstance.get("/history");
      setSearchHistory(response.data);
    } catch (error) {
      console.error("Error fetching search history:", error);
    }
  };

  // Function to convert 64-bit timestamp to milliseconds
  const convertTimestampToMilliseconds = (timestamp) => {
    const timestampMs = (timestamp.high * Math.pow(2, 32)) + timestamp.low;
    return timestampMs;
  };

  return (
    <div className="container min-h-screen w-1/2 mx-auto">
      <h1 className="text-2xl font-bold mb-4">Search History</h1>
      
      {searchHistory.map((item, index) => (
        <div key={index} className="py-2">
          <div className="bg-gray-100 p-2 flex items-center gap-8 rounded-lg">
            <p className="text-sm font-bold">{item.keyword}</p>
            {/* <p className="text-xs text-gray-500">
              Search Date-Time: {new Date(convertTimestampToMilliseconds(item.createdAt)).toLocaleString()}
            </p> */}
          </div>
        </div>
      ))}
      
    </div>
  );
};

export default SearchHistory;
