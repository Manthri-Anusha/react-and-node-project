import React, { useEffect } from 'react';
import { useCart } from '../Context/cartContext';
import { useNavigate } from 'react-router-dom';

const CartList = () => {
  const { cartItems, removeFromCart } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
  }, [cartItems]);

  const handleRemoveFromCart = ( productName) => {
    removeFromCart(productName);
      window.location.reload();
  };

const totalPrice = cartItems.reduce((acc, item) => {
  const priceString = item['Price in India'];
  const price = parseFloat(priceString.replace(/[^\d.]/g, '')) || 0;
  return acc + price;
}, 0);


  const handleBuyNow = () => {
    console.log(cartItems);
    if(totalPrice!==0){
    navigate('/payment');
    }
  };

  return (
    <div className="min-h-screen w-3/4 mx-auto mt-8 bg-white shadow-xl p-8 rounded-md">
      <h2 className="text-lg font-semibold mb-4">Cart</h2>
      {cartItems.length === 0 ? (
        <p className="text-gray-500">No items in cart</p>
      ) : (
        <div>
          <ul>
            {cartItems.map((item,index) => (
              <li key={index} className="border-b py-2">
                <div className="flex justify-between items-center">
                  <div>
                    
                    <p className="font-semibold">{item['Product Name']}</p>
                    <p className="text-gray-500">Price: {item['Price in India']}</p>
                  </div>
                  <button onClick={() => handleRemoveFromCart( item['Product Name'])} className=" bg-red-500 text-white py-2 px-4 rounded font-semibold hover:bg-red-700">Remove</button>
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-4">
            <p className="font-semibold">Total Price: {totalPrice}</p>
            <button onClick={handleBuyNow} className="mt-2 bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded">Buy Now</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartList;
