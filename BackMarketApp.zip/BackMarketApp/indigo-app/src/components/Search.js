import React, { useState } from "react";
import axiosInstance from "../api/axiosInstance";
import MobileCard from "./Mobilecard";

const SearchComponent = () => {
  const [keyword, setKeyword] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searchClicked, setSearchClicked] = useState(false); // State to track if search button is clicked

  const handleSearch = async () => {
    if (searchClicked) {
      try {
        const response = await axiosInstance.get(`/search?keyword=${keyword}`);
        setSearchResults(response.data);
      } catch (error) {
        console.error("Error searching:", error);
      }
    }
  };

  const handleInputChange = (e) => {
    const value = e.target.value;
    setKeyword(value);
  };

  const handleSearchButtonClick = () => {
    setSearchClicked(true); // Set searchClicked to true when search button is clicked
    handleSearch(); // Trigger search
  };

  return (
    <div className="container min-h-screen mx-auto p-4">
      <div>
        <input
          type="text"
          value={keyword}
          onChange={handleInputChange}
          placeholder="Enter keyword..."
          className="border border-gray-300 rounded px-4 py-2 w-full mb-4"
        />
      </div>
      <button
        onClick={handleSearchButtonClick}
        className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
      >
        Search
      </button>

      <div className="mt-8">
        {searchResults.length === 0 ? (
          <p className="text-lg text-gray-600">No items found.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {searchResults.map((product, index) => (
              <MobileCard
                key={index}
                mobile={product.product}
                category={product.category}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchComponent;
